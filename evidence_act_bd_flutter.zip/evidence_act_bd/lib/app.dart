import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/strings.dart';
import 'core/theme.dart';
import 'providers/providers.dart';
import 'ui/screens/home_screen.dart';
import 'ui/screens/learn_screen.dart';
import 'ui/screens/practice_screen.dart';
import 'ui/screens/profile_screen.dart';
import 'ui/screens/ranks_screen.dart';

class EvidenceActApp extends StatelessWidget {
  const EvidenceActApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Evidence Act BD',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const MainShell(),
      );
}

class MainShell extends ConsumerWidget {
  const MainShell({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tab = ref.watch(tabProvider);
    final s = S(ref.watch(isBanglaProvider));
    const pages = [HomeScreen(), LearnScreen(), PracticeScreen(), RanksScreen(), ProfileScreen()];
    final items = [
      (Icons.home_filled, s.t('home')), (Icons.menu_book, s.t('learn')), (Icons.sports_martial_arts, s.t('practice')),
      (Icons.emoji_events, s.t('ranks')), (Icons.person, s.t('profile')),
    ];
    return Scaffold(
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(color: AppColors.navy, border: Border(top: BorderSide(color: Colors.white12))),
        child: SafeArea(
          child: Row(children: [
            for (var i = 0; i < items.length; i++)
              Expanded(
                child: InkWell(
                  onTap: () => ref.read(tabProvider.notifier).state = i,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(border: Border(top: BorderSide(color: tab == i ? AppColors.gold : Colors.transparent, width: 3))),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(items[i].$1, color: tab == i ? AppColors.gold : AppColors.muted),
                      const SizedBox(height: 2),
                      Text(items[i].$2, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: tab == i ? AppColors.gold : AppColors.muted)),
                    ]),
                  ),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}
