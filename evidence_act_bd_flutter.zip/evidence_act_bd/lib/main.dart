import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app.dart';
import 'data/content_repository.dart';
import 'data/progress_store.dart';
import 'providers/providers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final content = await Content.load();
  final store = await HiveProgressStore.open();
  runApp(ProviderScope(
    overrides: [contentProvider.overrideWithValue(content), storeProvider.overrideWithValue(store)],
    child: const EvidenceActApp(),
  ));
}
